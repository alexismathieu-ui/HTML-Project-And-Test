Intégration responsive en mobile first.
Le contenu fait un maximum de 1100px de large mais le slider du titre de page et le fond de couleur du pied de page font toute la largeur de l'écran quelque soit sa taille.
Points de rupture :
- tablette : 780px
- desktop : 980px

COULEURS

- gris clair : #ededed
- bleu foncé : #1d1e3d
- turquoise : #037d9d
- orange : #fb8038
- rose : #db0059

POLICES 
- Par défaut : Source Sans Pro (Google font)
- Titres, nav et citation : Mali (Google font)

TAILLE DES POLICES
- par défaut : 16px
- menu : 24px
- Titre de page : 30px
- citation : 25px et 20px
- Titres de rubriques : 28px
- Titres d'articles : 20px
- date des articles : 14px


Les pictos sont des Font Awesome.